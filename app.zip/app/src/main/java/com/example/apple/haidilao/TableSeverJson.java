package com.example.apple.haidilao;

import java.util.HashMap;
import java.util.Map;

public class TableSeverJson {
    String message;

    private TableInfo table;

    public TableInfo getTable() {
        return table;
    }

    public void setTable(TableInfo table) {
        this.table = table;
    }
}
