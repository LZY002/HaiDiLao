package com.example.apple.haidilao;

public class ClientSeverJson {
    String message;
    String level;

    public String getLevel() {
        return level;
    }

    public String getMessage() {
        return message;
    }
}
