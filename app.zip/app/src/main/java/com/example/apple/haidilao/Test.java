package com.example.apple.haidilao;


import org.eclipse.paho.android.service.MqttAndroidClient;

import org.eclipse.paho.client.mqttv3.MqttConnectOptions;

public class Test  {

    public static void main(String[] args) {
        MqttAndroidClient client;
        MqttConnectOptions conOpt;
        String host = "tcp://10.212.112.112:88888";
        String username = "admin";
        String password = "password";
        String myTopic = "Information";
        String clientId = "anzhuo";




    }
}
