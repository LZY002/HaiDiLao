package com.example.apple.haidilao;

public class TableChosenSeverJson {
    String queuenumber;
    int waitnumber;

    public String getQueuenumber() {
        return queuenumber;
    }

    public int getWaitnumber() {
        return waitnumber;
    }
}
