package com.example.apple.haidilao;

public interface IGetMessageCallBack {
    public  void setMessage(String message);
}
