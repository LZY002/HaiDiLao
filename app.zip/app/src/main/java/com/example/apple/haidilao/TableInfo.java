package com.example.apple.haidilao;


public class TableInfo {

    private int small;
    private int middle;
    private int big;

    public int getSmall() {
        return small;
    }

    public void setSmall(int small) {
        this.small = small;
    }

    public int getMiddle() {
        return middle;
    }

    public void setMiddle(int middle) {
        this.middle = middle;
    }

    public int getBig() {
        return big;
    }

    public void setBig(int big) {
        this.big = big;
    }
}
