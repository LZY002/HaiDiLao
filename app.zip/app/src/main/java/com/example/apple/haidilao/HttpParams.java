package com.example.apple.haidilao;


public class HttpParams {

    public static final String URL = "http://172.20.10.2";
}
